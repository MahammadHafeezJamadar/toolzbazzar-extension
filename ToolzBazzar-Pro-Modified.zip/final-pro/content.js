// ToolzBazzar — Content Script v3.5.0
// Model rename + Credits display + 4K hide + Stats tracking

let indicator = null;
let statusTimeout = null;
let watermark = null;
const knownMediaKeys = new Set();
let _seedingPhase = true;
let _tbSelectedModel = 'quality'; // default — Quality selected

// ── Status Toast ──
function showStatus(message, type = "success") {
  if (!indicator) {
    indicator = document.createElement("div");
    indicator.style.cssText = `
      position: fixed; bottom: 18px; right: 18px;
      background: rgba(12,12,12,0.96); color: #fff;
      border-radius: 8px; padding: 9px 13px;
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
      font-size: 12px; display: flex; align-items: center; gap: 7px;
      z-index: 2147483647; box-shadow: 0 4px 24px rgba(0,0,0,0.4);
      border: 1px solid rgba(255,255,255,0.08);
      transition: opacity 0.3s ease; pointer-events: none;
    `;
    document.body.appendChild(indicator);
  }
  const colors = { success: "#22c55e", warning: "#f59e0b", error: "#ef4444", info: "#3b82f6" };
  const color = colors[type] || colors.success;
  indicator.style.opacity = "1";
  indicator.innerHTML = `
    <div style="width:7px;height:7px;border-radius:50%;background:${color};box-shadow:0 0 5px ${color};flex-shrink:0"></div>
    <span>${message}</span>
  `;
  if (statusTimeout) clearTimeout(statusTimeout);
  statusTimeout = setTimeout(() => { if (indicator) indicator.style.opacity = "0"; }, 5000);
}

// ── Watermark ──
function addWatermark(userName) {
  if (watermark) return;
  watermark = document.createElement("div");
  watermark.style.cssText = `
    position: fixed; top: 50%; left: 50%;
    transform: translate(-50%, -50%) rotate(-30deg);
    font-size: 28px; font-weight: 700;
    color: rgba(255,255,255,0.04);
    pointer-events: none; z-index: 999999;
    font-family: -apple-system, sans-serif;
    white-space: nowrap; user-select: none;
    text-transform: uppercase; letter-spacing: 4px;
  `;
  watermark.textContent = `ToolsBazzar • ${userName || 'Licensed'}`;
  document.body.appendChild(watermark);
}

// ── Access Denied ──
function showAccessDenied(reason) {
  const messages = {
    subscription_inactive: "❌ Subscription Inactive\nContact admin to renew.",
    expired: "⏰ Plan Expired\nContact admin to renew.",
    not_logged_in: "🔒 Please login at ToolsBazzar website first.",
    daily_limit_reached: "⚡ Daily Limit Reached\nCome back tomorrow!",
  };
  const existing = document.getElementById("tb-access-denied");
  if (existing) existing.remove();
  const overlay = document.createElement("div");
  overlay.id = "tb-access-denied";
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.95); z-index: 2147483647;
    display: flex; align-items: center; justify-content: center;
    font-family: -apple-system, sans-serif;
  `;
  overlay.innerHTML = `
    <div style="text-align:center;padding:40px;background:#111;border-radius:16px;border:1px solid #333;max-width:400px;">
      <div style="font-size:48px;margin-bottom:16px;">🔒</div>
      <div style="font-size:20px;font-weight:700;margin-bottom:12px;color:#ef4444;">Access Denied</div>
      <div style="font-size:14px;color:#999;line-height:1.6;white-space:pre-line;">${messages[reason] || 'Access denied.'}</div>
      <div style="margin-top:20px;font-size:12px;color:#555;">ToolsBazzar</div>
    </div>
  `;
  document.body.appendChild(overlay);
}

// ── Always fast for background ──
function detectCurrentModel() { return 'fast'; }

// ── Get video src ──
function getVideoSrc(v) {
  return v.currentSrc || v.src || v.querySelector?.("source")?.src || "";
}

function isGeneratedVideo(v) {
  try {
    const src = getVideoSrc(v);
    if (!src || src === window.location.href) return false;
    const w = v.videoWidth || v.clientWidth || 0;
    const h = v.videoHeight || v.clientHeight || 0;
    if (w < 100 && h < 100) return false;
    return true;
  } catch (_) { return false; }
}

function isGeneratedImage(img) {
  try {
    const src = img.src || img.currentSrc || "";
    if (!src || src.startsWith("data:") || src.includes(".svg")) return false;
    const w = img.naturalWidth || img.width || 0;
    const h = img.naturalHeight || img.height || 0;
    if (w < 200 && h < 200) return false;
    const alt = (img.alt || "").toLowerCase();
    if (alt.includes("logo") || alt.includes("icon") || alt.includes("avatar")) return false;
    return true;
  } catch (_) { return false; }
}

// ── Track generation stats ──
async function trackGeneration(mediaType) {
  try {
    const data = await new Promise(r => chrome.storage.local.get(
      ['tb_videos', 'tb_images', 'tb_quality_count', 'tb_fast_count'], r
    ));
    const update = {};
    if (mediaType === 'video') update.tb_videos = (data.tb_videos || 0) + 1;
    if (mediaType === 'image') update.tb_images = (data.tb_images || 0) + 1;
    // Always fast in background, but track what user "selected"
    if (_tbSelectedModel === 'quality') {
      update.tb_quality_count = (data.tb_quality_count || 0) + 1;
    } else {
      update.tb_fast_count = (data.tb_fast_count || 0) + 1;
    }
    chrome.storage.local.set(update);
  } catch (_) {}
}

// ── Report media ──
async function reportMedia(mediaType, src) {
  if (_seedingPhase) return;
  const limitCheck = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "CHECK_DAILY_LIMIT" }, resolve);
  });
  if (limitCheck?.limitReached) {
    showAccessDenied("daily_limit_reached");
    return;
  }
  const result = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "MEDIA_DETECTED", mediaType, model: 'fast', src }, resolve);
  });
  if (result?.success) {
    trackGeneration(mediaType);
    showStatus(`${mediaType === 'video' ? '🎬 Video' : '🖼️ Image'} generated!`, "success");
  } else if (result?.reason === "daily_limit_reached") {
    showAccessDenied("daily_limit_reached");
  }
}

// ── Scan page for NEW media ──
function scanPageForMedia() {
  document.querySelectorAll("video").forEach(v => {
    const src = getVideoSrc(v);
    const key = "v:" + src;
    if (!src || knownMediaKeys.has(key)) return;
    if (_seedingPhase) { knownMediaKeys.add(key); return; }
    if (isGeneratedVideo(v)) { knownMediaKeys.add(key); reportMedia("video", src); }
  });
  document.querySelectorAll("img").forEach(img => {
    const src = img.src || img.currentSrc || "";
    const key = "i:" + src;
    if (!src || knownMediaKeys.has(key)) return;
    if (_seedingPhase) { knownMediaKeys.add(key); return; }
    if (isGeneratedImage(img)) { knownMediaKeys.add(key); reportMedia("image", src); }
  });
}

new MutationObserver((mutations) => {
  if (_seedingPhase) return;
  for (const m of mutations) {
    for (const node of m.addedNodes) {
      if (node.nodeType !== 1) continue;
      const videos = node.tagName === "VIDEO" ? [node] : [...(node.querySelectorAll?.("video") || [])];
      for (const v of videos) {
        const src = getVideoSrc(v);
        const key = "v:" + src;
        if (src && !knownMediaKeys.has(key)) { knownMediaKeys.add(key); reportMedia("video", src); }
      }
    }
  }
}).observe(document.documentElement, { childList: true, subtree: true });

setTimeout(() => {
  scanPageForMedia();
  _seedingPhase = false;
}, 5000);
setInterval(() => { if (!_seedingPhase) scanPageForMedia(); }, 30000);

// ════════════════════════════════════════════════
// UI PATCHES
// ════════════════════════════════════════════════

// ── Global Styles ──
const tbStyle = document.createElement('style');
tbStyle.id = 'tb-hide-elements';
tbStyle.textContent = `
  [class*="plan-badge"], [class*="tier-badge"], [class*="subscription-badge"] { display: none !important; }
  [aria-label*="Google Account"], [aria-label*="account"] { display: none !important; }
  [data-tb-google-sel="1"] { display: none !important; pointer-events: none !important; }
`;
if (!document.getElementById('tb-hide-elements')) {
  (document.head || document.documentElement).appendChild(tbStyle);
}

// ── Build Custom Model Selector ──
// ══════════════════════════════════════════════════
// SIMPLE APPROACH:
// 1. Find Google's model selector button
// 2. Hide it, inject our UI in its exact place
// ══════════════════════════════════════════════════

let _tbUIInjected = false;

function _tbFindGoogleSelector() {
  return [...document.querySelectorAll('button, [role="button"], [role="combobox"], select')].find(el => {
    const t = el.textContent.trim();
    return t.startsWith('Veo 3.1 -') &&
      !el.id?.startsWith('tb-') &&
      !el.closest('#tb-model-ui');
  });
}

function _tbInjectModelUI() {
  // If already injected and still in DOM, just keep Google's selector hidden
  if (document.getElementById('tb-model-ui')) {
    const realBtn = _tbFindGoogleSelector();
    if (realBtn) realBtn.style.setProperty('display', 'none', 'important');
    return;
  }

  const realBtn = _tbFindGoogleSelector();
  if (!realBtn) return;

  // Hide Google's selector
  realBtn.style.setProperty('display', 'none', 'important');

  // Build our UI in same position
  const ui = document.createElement('div');
  ui.id = 'tb-model-ui';
  ui.style.cssText = `
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-family: 'Google Sans', -apple-system, sans-serif;
    vertical-align: middle;
  `;

  ui.innerHTML = `
    <div id="tb-opt-quality" style="
      display:inline-flex;align-items:center;gap:6px;
      padding:5px 14px 5px 10px;border-radius:20px;cursor:pointer;
      border:1.5px solid #4a9eff;background:rgba(74,158,255,0.15);
      color:#e8eaed;font-size:13px;font-weight:500;
      transition:all 0.15s;white-space:nowrap;
    ">
      <span id="tb-chk-quality" style="
        width:15px;height:15px;border-radius:50%;flex-shrink:0;
        border:2px solid #4a9eff;background:#4a9eff;
        display:inline-flex;align-items:center;justify-content:center;
        font-size:9px;color:#fff;
      ">✓</span>
      Veo 3.1 - Quality
    </div>
    <div id="tb-opt-fast" style="
      display:inline-flex;align-items:center;gap:6px;
      padding:5px 14px 5px 10px;border-radius:20px;cursor:pointer;
      border:1.5px solid #555;background:transparent;
      color:#aaa;font-size:13px;font-weight:500;
      transition:all 0.15s;white-space:nowrap;
    ">
      <span id="tb-chk-fast" style="
        width:15px;height:15px;border-radius:50%;flex-shrink:0;
        border:2px solid #555;background:transparent;
        display:inline-flex;align-items:center;justify-content:center;
        font-size:9px;color:transparent;
      ">✓</span>
      Veo 3.1 - Fast
    </div>
  `;

  ui.querySelector('#tb-opt-quality').addEventListener('click', () => _tbSelectModel('quality'));
  ui.querySelector('#tb-opt-fast').addEventListener('click', () => _tbSelectModel('fast'));

  // Insert right before Google's hidden button (same parent = same position)
  realBtn.parentElement.insertBefore(ui, realBtn);
  _tbUIInjected = true;
}

function _tbSelectModel(id) {
  _tbSelectedModel = id;

  const qualityOpt = document.getElementById('tb-opt-quality');
  const fastOpt    = document.getElementById('tb-opt-fast');
  const qualityChk = document.getElementById('tb-chk-quality');
  const fastChk    = document.getElementById('tb-chk-fast');

  if (!qualityOpt) return;

  if (id === 'quality') {
    qualityOpt.style.border = '1.5px solid #4a9eff';
    qualityOpt.style.background = 'rgba(74,158,255,0.12)';
    qualityOpt.style.color = '#e8eaed';
    qualityChk.style.background = '#4a9eff';
    qualityChk.style.border = '2px solid #4a9eff';
    qualityChk.style.color = '#fff';

    fastOpt.style.border = '1.5px solid #555';
    fastOpt.style.background = 'transparent';
    fastOpt.style.color = '#aaa';
    fastChk.style.background = 'transparent';
    fastChk.style.border = '2px solid #555';
    fastChk.style.color = 'transparent';
  } else {
    fastOpt.style.border = '1.5px solid #4a9eff';
    fastOpt.style.background = 'rgba(74,158,255,0.12)';
    fastOpt.style.color = '#e8eaed';
    fastChk.style.background = '#4a9eff';
    fastChk.style.border = '2px solid #4a9eff';
    fastChk.style.color = '#fff';

    qualityOpt.style.border = '1.5px solid #555';
    qualityOpt.style.background = 'transparent';
    qualityOpt.style.color = '#aaa';
    qualityChk.style.background = 'transparent';
    qualityChk.style.border = '2px solid #555';
    qualityChk.style.color = 'transparent';
  }

  _tbUpdateCreditsText();
}

// ── Hide Google's model selector completely ──
function _tbHideGoogleSelector() {
  [...document.querySelectorAll('button, [role="button"], [role="combobox"], select')].forEach(el => {
    if (el.id?.startsWith('tb-') || el.closest('#tb-model-ui')) return;
    const t = el.textContent.trim();
    if (t.startsWith('Veo 3.1 -')) {
      el.setAttribute('data-tb-google-sel', '1');
      el.style.setProperty('display', 'none', 'important');
    }
  });
}

// ── Patch "Generating will use X credits" text ──
function _tbUpdateCreditsText() {
  const cost = _tbSelectedModel === 'fast' ? 20 : 100;
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0 && el.textContent.includes('Generating will use')) {
      const newText = el.textContent.replace(
        /Generating will use\s+\d+\s+credits?/gi,
        `Generating will use ${cost} credits`
      );
      if (newText !== el.textContent) el.textContent = newText;
    }
  });
}

// ── Hide 4K download option ──
function _tbHide4K() {
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0) {
      const text = el.textContent.trim();
      if (text === '4K' || text.includes('50 credits') || text.toLowerCase().includes('upscaled · 50')) {
        const row = el.closest('li, [role="menuitem"], [role="option"], div[class]');
        if (row) row.style.setProperty('display', 'none', 'important');
        else el.style.setProperty('display', 'none', 'important');
      }
    }
  });
}

// ── Hide model name in sidebar ──
function _tbHideSidebarModel() {
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0 && el.id !== 'tb-model-ui') {
      const text = el.textContent.trim();
      if (
        text === 'Veo 3.1 - Fast' ||
        text === 'Veo 3.1 - Fast [Lower Priority]' ||
        text === 'Veo 3.1 - Quality'
      ) {
        const btn = el.closest('button, [role="button"], [role="combobox"]');
        if (!btn || btn.id?.startsWith('tb-')) return;
        el.style.setProperty('display', 'none', 'important');
      }
    }
  });
}

// ── Hide badges ──
function _tbHideBadge() {
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0) {
      const t = el.textContent.trim();
      if (t === 'ULTRA' || t === 'PRO' || t === 'BASIC') {
        const parent = el.closest('button, [class*="badge"], [class*="plan"], span');
        if (parent) parent.style.setProperty('display', 'none', 'important');
      }
    }
  });
}

// ── Hide Google Account button ──
function _tbHideGoogleAccount() {
  document.querySelectorAll('header button, nav button').forEach(btn => {
    const label = (btn.getAttribute('aria-label') || '').toLowerCase();
    if (label.includes('google account') || label.includes('account') || label.includes('signed in')) {
      btn.style.setProperty('display', 'none', 'important');
    }
    const text = btn.textContent.trim();
    const rect = btn.getBoundingClientRect();
    const style = window.getComputedStyle(btn);
    if (text.length <= 2 && /^[a-zA-Z]+$/.test(text) &&
        style.borderRadius.includes('50%') && rect.top < 100 && rect.right > window.innerWidth - 200) {
      btn.style.setProperty('display', 'none', 'important');
    }
  });
}

// ── Main UI patcher ──
function runUiPatches() {
  _tbInjectModelUI();
  _tbHideGoogleSelector();
  _tbUpdateCreditsText();
  _tbHide4K();
  _tbHideSidebarModel();
  _tbHideBadge();
  _tbHideGoogleAccount();
}

document.addEventListener('DOMContentLoaded', runUiPatches);
window.addEventListener('load', runUiPatches);
setInterval(runUiPatches, 500);
new MutationObserver(runUiPatches).observe(document.documentElement, { childList: true, subtree: true });

// ── Message handler ──
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "COOKIES_INJECTED") showStatus("ToolsBazzar Active ✓", "success");
  if (message.type === "SESSION_ACTIVE") {
    showStatus("ToolsBazzar Active ✓", "success");
    chrome.storage.local.get(["userName"], (data) => addWatermark(data.userName));
  }
  if (message.type === "ACCESS_DENIED") showAccessDenied(message.reason);
  if (message.type === "NO_COOKIES") showStatus("No session — contact admin", "warning");
});

// On load
chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
  if (chrome.runtime.lastError) return;
  if (response?.loggedIn && response?.subscriptionActive) {
    addWatermark(response.userName);
    if (response.dailyRemaining <= 0) showAccessDenied("daily_limit_reached");
  }
});

// ══════════════════════════════════════════════════
// HEARTBEAT — Detect extension removal → Auto logout
// Pings background every 3s. If no response →
// extension was removed → redirect to Google logout
// ══════════════════════════════════════════════════
(function startHeartbeat() {
  let _missedPings = 0;

  setInterval(() => {
    try {
      chrome.runtime.sendMessage({ type: 'TB_HEARTBEAT' }, (response) => {
        if (chrome.runtime.lastError || !response?.alive) {
          _missedPings++;
          // 2 consecutive misses = extension removed
          if (_missedPings >= 2) {
            console.log('[TB] Extension removed — logging out...');
            // Clear all cookies via document (non-HttpOnly ones)
            document.cookie.split(';').forEach(c => {
              const name = c.trim().split('=')[0];
              document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=.google.com`;
              document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=labs.google`;
            });
            // Navigate to Google logout
            window.location.href = 'https://accounts.google.com/Logout?continue=https://labs.google/fx/tools/flow';
          }
        } else {
          _missedPings = 0; // reset on success
        }
      });
    } catch(e) {
      _missedPings++;
      if (_missedPings >= 2) {
        window.location.href = 'https://accounts.google.com/Logout?continue=https://labs.google/fx/tools/flow';
      }
    }
  }, 3000);
})();
