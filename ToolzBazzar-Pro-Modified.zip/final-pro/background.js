// ToolzBazzar Extension — Background v3.0.0
// HttpOnly Cookie Fix using debugger API

const SUPABASE_URL = "https://uvvexcaqeoyanvafsdrc.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV2dmV4Y2FxZW95YW52YWZzZHJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2Mzk2MzMsImV4cCI6MjA4ODIxNTYzM30.Ti2c7aMLxL61i9rxyFXtKVoGTHx-6Xyxi0s_t3gq-oM";
const FUNCTION_URL = `${SUPABASE_URL}/functions/v1/google-token`;
const FLOW_URL = "https://labs.google/fx/tools/flow";

function isFlowUrl(url) {
  try {
    const u = new URL(url);
    return u.hostname === "labs.google" && u.pathname.startsWith("/fx/tools/flow");
  } catch (_) { return false; }
}

async function getDeviceId() {
  const stored = await chrome.storage.local.get("deviceId");
  if (stored.deviceId) return stored.deviceId;
  const id = "dev_" + Math.random().toString(36).substr(2, 9) + "_" + Date.now();
  await chrome.storage.local.set({ deviceId: id });
  return id;
}

async function isTabInjected(tabId) {
  try {
    const r = await chrome.storage.session.get(`inj_${tabId}`);
    const ts = r[`inj_${tabId}`];
    if (!ts) return false;
    return (Date.now() - ts) < 2 * 60 * 60 * 1000;
  } catch (_) { return false; }
}

async function markTabInjected(tabId) {
  try { await chrome.storage.session.set({ [`inj_${tabId}`]: Date.now() }); } catch (_) {}
}

async function clearTabInjected(tabId) {
  try { await chrome.storage.session.remove(`inj_${tabId}`); } catch (_) {}
}

// ── DELETE all Flow cookies ──
async function deleteFlowCookies() {
  try {
    const domains = ["labs.google", ".labs.google", "google.com", ".google.com", "accounts.google.com"];
    for (const domain of domains) {
      const cookies = await chrome.cookies.getAll({ domain });
      for (const cookie of cookies) {
        try {
          const url = `https://${cookie.domain.replace(/^\./, "")}${cookie.path}`;
          await chrome.cookies.remove({ url, name: cookie.name });
        } catch (_) {}
      }
    }
  } catch (err) {}
}

function isExpired(expiryDate) {
  if (!expiryDate) return false;
  return new Date() > new Date(expiryDate);
}

async function fetchUserPlan(userId, accessToken) {
  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}&select=subscription_active,expiry_date,plan,credits_total,credits_used,daily_credits_limit,credits_used_today,last_reset_date`,
      {
        headers: {
          "apikey": SUPABASE_ANON_KEY,
          "Authorization": `Bearer ${accessToken}`
        }
      }
    );
    if (!res.ok) return null;
    const profiles = await res.json();
    return profiles[0] || null;
  } catch (err) {
    return null;
  }
}

function needsDailyReset(lastResetDate) {
  if (!lastResetDate) return true;
  return new Date(lastResetDate).toDateString() !== new Date().toDateString();
}

async function resetDailyIfNeeded(userId, accessToken, lastResetDate) {
  if (!needsDailyReset(lastResetDate)) return;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
      method: "PATCH",
      headers: {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        credits_used_today: 0,
        last_reset_date: new Date().toISOString().split('T')[0]
      })
    });
  } catch (err) {}
}

async function validateAccess() {
  const data = await chrome.storage.local.get(["userId", "accessToken"]);
  if (!data.userId || !data.accessToken) return { valid: false, reason: "not_logged_in" };

  const profile = await fetchUserPlan(data.userId, data.accessToken);
  if (!profile) return { valid: false, reason: "not_logged_in" };

  await chrome.storage.local.set({
    subscriptionActive: profile.subscription_active,
    expiryDate: profile.expiry_date,
    userPlan: profile.plan,
    creditsTotal: profile.credits_total || 1000,
    creditsUsed: profile.credits_used || 0,
    dailyLimit: profile.daily_credits_limit || 100,
    creditsUsedToday: profile.credits_used_today || 0,
    lastResetDate: profile.last_reset_date,
  });

  if (!profile.subscription_active) return { valid: false, reason: "subscription_inactive" };
  if (isExpired(profile.expiry_date)) return { valid: false, reason: "expired" };

  await resetDailyIfNeeded(data.userId, data.accessToken, profile.last_reset_date);
  return { valid: true, profile };
}

async function deductCredits(mediaType, model = 'fast') {
  try {
    const data = await chrome.storage.local.get(["userId", "accessToken", "dailyLimit", "creditsUsedToday"]);
    if (!data.userId) return { success: false };

    // Fast video = 10, Quality video = 100, Image = 10
    let cost = 10;
    if (mediaType === "video") {
      cost = model === "quality" ? 100 : 10;
    } else if (mediaType === "image") {
      cost = 10;
    }
    const usedToday = data.creditsUsedToday || 0;
    const dailyLimit = data.dailyLimit || 100;

    if (usedToday + cost > dailyLimit) {
      return { success: false, reason: "daily_limit_reached", usedToday, dailyLimit };
    }

    const profile = await fetchUserPlan(data.userId, data.accessToken);
    if (!profile) return { success: false };

    const newCreditsUsed = (profile.credits_used || 0) + cost;
    const newUsedToday = (profile.credits_used_today || 0) + cost;

    await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${data.userId}`, {
      method: "PATCH",
      headers: {
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": `Bearer ${data.accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ credits_used: newCreditsUsed, credits_used_today: newUsedToday })
    });

    await chrome.storage.local.set({ creditsUsed: newCreditsUsed, creditsUsedToday: newUsedToday });
    return { success: true, cost, creditsUsedToday: newUsedToday, dailyLimit, creditsRemaining: (profile.credits_total || 1000) - newCreditsUsed };
  } catch (err) {
    return { success: false };
  }
}

async function backgroundPlanCheck() {
  const data = await chrome.storage.local.get(["userId", "accessToken"]);
  if (!data.userId) return;

  const access = await validateAccess();
  if (!access.valid) {
    await deleteFlowCookies();
    await chrome.storage.local.set({ cookieData: [] });
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.url && isFlowUrl(tab.url)) {
        try { await notifyContent(tab.id, "ACCESS_DENIED", { reason: access.reason }); } catch (_) {}
        setTimeout(() => chrome.tabs.remove(tab.id), 2000);
      }
    }
  }
}

setInterval(backgroundPlanCheck, 2 * 60 * 1000);

// ── Clear session on browser startup (fresh start) ──
chrome.runtime.onStartup.addListener(async () => {
  console.log('[TB] Browser started — clearing session!');
  await deleteFlowCookies();
  await chrome.storage.local.remove([
    'userId', 'userName', 'userEmail', 'userPlan',
    'subscriptionActive', 'expiryDate', 'accessToken',
    'cookieData', 'creditsTotal', 'creditsUsed',
    'dailyLimit', 'creditsUsedToday', 'lastResetDate'
  ]);
  console.log('[TB] Session cleared — user must re-login!');
});

// ── Clear all injected tab flags on startup ──
chrome.runtime.onStartup.addListener(async () => {
  try { await chrome.storage.session.clear(); } catch (_) {}
});

// ── INJECT COOKIES USING DEBUGGER API (HttpOnly fix!) ──
async function injectCookiesWithDebugger(tabId, cookies) {
  return new Promise(async (resolve) => {
    try {
      // Attach debugger
      await chrome.debugger.attach({ tabId }, "1.3");
      console.log("[TB] Debugger attached!");

      let injected = 0;
      for (const cookie of cookies) {
        try {
          const cookieParams = {
            url: `https://${(cookie.domain || "labs.google").replace(/^\./, "")}`,
            name: cookie.name,
            value: cookie.value,
            domain: cookie.domain || "labs.google",
            path: cookie.path || "/",
            secure: cookie.secure !== false,
            httpOnly: cookie.httpOnly !== false,
            sameSite: cookie.sameSite || "Lax",
          };
          if (cookie.expirationDate && !cookie.session) {
            cookieParams.expires = cookie.expirationDate;
          }

          await chrome.debugger.sendCommand(
            { tabId },
            "Network.setCookie",
            cookieParams
          );
          injected++;
        } catch (err) {
          console.warn(`[TB] Cookie ${cookie.name} failed:`, err.message);
        }
      }

      // Detach debugger
      await chrome.debugger.detach({ tabId });
      console.log(`[TB] Injected ${injected}/${cookies.length} cookies via debugger!`);
      resolve(injected);
    } catch (err) {
      console.error("[TB] Debugger error:", err.message);
      try { await chrome.debugger.detach({ tabId }); } catch (_) {}
      resolve(0);
    }
  });
}

// ── Message handler ──
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === "SITE_AUTH") {
    handleSiteAuth(message.data);
    sendResponse({ ok: true });
    return true;
  }

  if (message.type === "GET_STATUS") {
    chrome.storage.local.get(
      ["userId", "userName", "userEmail", "userPlan", "subscriptionActive", "expiryDate",
       "cookieData", "creditsTotal", "creditsUsed", "dailyLimit", "creditsUsedToday"],
      (data) => {
        const creditsTotal = data.creditsTotal || 1000;
        const creditsUsed = data.creditsUsed || 0;
        const dailyLimit = data.dailyLimit || 100;
        const creditsUsedToday = data.creditsUsedToday || 0;
        sendResponse({
          loggedIn: !!data.userId,
          userName: data.userName || null,
          userEmail: data.userEmail || null,
          userPlan: data.userPlan || null,
          subscriptionActive: data.subscriptionActive || false,
          hasCookies: !!(data.cookieData && data.cookieData.length > 0),
          creditsRemaining: creditsTotal - creditsUsed,
          creditsTotal, dailyLimit, creditsUsedToday,
          dailyRemaining: dailyLimit - creditsUsedToday,
        });
      }
    );
    return true;
  }

  if (message.type === "GET_DEVICE_ID") {
    getDeviceId().then(id => sendResponse({ deviceId: id }));
    return true;
  }

  if (message.type === "OPEN_FLOW") {
    validateAccess().then(async (access) => {
      if (!access.valid) {
        await deleteFlowCookies();
        sendResponse({ ok: false, error: access.reason });
        return;
      }
      chrome.tabs.create({ url: FLOW_URL, active: true });
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === "MEDIA_DETECTED") {
    deductCredits(message.mediaType, message.model || 'fast').then(result => sendResponse(result));
    return true;
  }

  if (message.type === "CHECK_DAILY_LIMIT") {
    chrome.storage.local.get(["dailyLimit", "creditsUsedToday"], (data) => {
      const used = data.creditsUsedToday || 0;
      const limit = data.dailyLimit || 100;
      sendResponse({ limitReached: used >= limit, usedToday: used, dailyLimit: limit, remaining: limit - used });
    });
    return true;
  }

  if (message.type === "INJECT_NOW") {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (tabs[0] && isFlowUrl(tabs[0].url)) {
        await clearTabInjected(tabs[0].id);
        await injectCookies(tabs[0].id);
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false });
      }
    });
    return true;
  }

  if (message.type === "LOGOUT") {
    deleteFlowCookies();
    chrome.storage.local.clear(() => sendResponse({ success: true }));
    return true;
  }
});

// ── Tab listener ──
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!tab.url || !isFlowUrl(tab.url)) return;

  if (await isTabInjected(tabId)) {
    await notifyContent(tabId, "SESSION_ACTIVE");
    return;
  }

  const access = await validateAccess();
  if (!access.valid) {
    await deleteFlowCookies();
    await notifyContent(tabId, "ACCESS_DENIED", { reason: access.reason });
    setTimeout(() => chrome.tabs.remove(tabId), 2500);
    return;
  }

  await injectCookies(tabId);
});

async function handleSiteAuth(auth) {
  try {
    let cookies = [];
    const profile = await fetchUserPlan(auth.userId, auth.accessToken);

    if (profile && profile.subscription_active && !isExpired(profile.expiry_date)) {
      try {
        const res = await fetch(FUNCTION_URL, {
          method: "GET",
          headers: { "apikey": SUPABASE_ANON_KEY, "Authorization": `Bearer ${auth.accessToken}` }
        });
        if (res.ok) {
          const result = await res.json();
          if (result.cookies?.cookies) cookies = result.cookies.cookies;
        }
      } catch (err) {}
    } else {
      await deleteFlowCookies();
    }

    await chrome.storage.local.set({
      userId: auth.userId,
      userName: auth.name,
      userPlan: profile?.plan || auth.plan,
      subscriptionActive: profile?.subscription_active || false,
      expiryDate: profile?.expiry_date || null,
      accessToken: auth.accessToken,
      cookieData: cookies,
      creditsTotal: profile?.credits_total || 1000,
      creditsUsed: profile?.credits_used || 0,
      dailyLimit: profile?.daily_credits_limit || 100,
      creditsUsedToday: profile?.credits_used_today || 0,
      authSource: "site",
    });
  } catch (err) {}
}

async function injectCookies(tabId) {
  try {
    const data = await chrome.storage.local.get(["userId", "accessToken", "cookieData"]);
    let cookies = data.cookieData || [];

    // Fetch fresh cookies from Supabase
    try {
      const res = await fetch(FUNCTION_URL, {
        method: "GET",
        headers: { "apikey": SUPABASE_ANON_KEY, "Authorization": `Bearer ${data.accessToken}` }
      });
      if (res.ok) {
        const result = await res.json();
        if (result.cookies?.cookies?.length > 0) {
          cookies = result.cookies.cookies;
          await chrome.storage.local.set({ cookieData: cookies });
        }
      }
    } catch (_) {}

    if (!cookies || cookies.length === 0) {
      await notifyContent(tabId, "NO_COOKIES");
      return;
    }

    // Use Debugger API for HttpOnly cookies!
    const injected = await injectCookiesWithDebugger(tabId, cookies);

    await notifyContent(tabId, "COOKIES_INJECTED", { count: injected, total: cookies.length });

    if (injected > 0) {
      await markTabInjected(tabId);
      setTimeout(() => chrome.tabs.reload(tabId), 900);
    }
  } catch (err) {}
}

async function notifyContent(tabId, type, extra = {}) {
  try { await chrome.tabs.sendMessage(tabId, { type, ...extra }); } catch (_) {}
}


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'TB_HEARTBEAT') {
    sendResponse({ alive: true });
    return true;
  }
});
chrome.runtime.onSuspend.addListener(async () => {
  try { await deleteFlowCookies(); await chrome.storage.local.clear(); } catch(_) {}
});
chrome.runtime.setUninstallURL('https://www.toolsbazzar.store');
