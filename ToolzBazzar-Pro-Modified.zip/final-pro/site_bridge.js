// ToolzBazzar — Site Bridge v2.0
// Sends logged in user info to extension

(function () {
  const SUPABASE_URL = "https://uvvexcaqeoyanvafsdrc.supabase.co";
  const ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV2dmV4Y2FxZW95YW52YWZzZHJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2Mzk2MzMsImV4cCI6MjA4ODIxNTYzM30.Ti2c7aMLxL61i9rxyFXtKVoGTHx-6Xyxi0s_t3gq-oM";

  async function sendAuth() {
    try {
      const keys = Object.keys(localStorage);
      const sbKey = keys.find(k => (k.includes('supabase') || k.includes('sb-')) && k.includes('auth'));
      if (!sbKey) return;
      const raw = localStorage.getItem(sbKey);
      if (!raw) return;
      const session = JSON.parse(raw);
      const user = session?.user;
      const accessToken = session?.access_token;
      if (!user || !accessToken) return;

      const res = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${user.id}&select=*`, {
        headers: {
          "apikey": ANON_KEY,
          "Authorization": `Bearer ${accessToken}`
        }
      });

      const profiles = await res.json();
      const profile = profiles[0] || {};

      // Register extension device
      const deviceId = await getDeviceId();
      try {
        await fetch(`${SUPABASE_URL}/rest/v1/user_sessions`, {
          method: "POST",
          headers: {
            "apikey": ANON_KEY,
            "Authorization": `Bearer ${accessToken}`,
            "Content-Type": "application/json",
            "Prefer": "resolution=merge-duplicates"
          },
          body: JSON.stringify({
            user_id: user.id,
            email: user.email,
            device_id: deviceId,
            device_info: `Extension: ${navigator.userAgent}`,
            last_active_time: new Date().toISOString()
          })
        });
      } catch (_) {}

      chrome.runtime.sendMessage({
        type: "SITE_AUTH",
        data: {
          userId: user.id,
          email: user.email,  // Important: website email
          name: profile.name || user.email?.split('@')[0] || "User",
          plan: profile.plan || "basic",
          subscriptionActive: profile.subscription_active || false,
          expiryDate: profile.expiry_date || null,
          accessToken: accessToken,
        }
      }, () => { if (chrome.runtime.lastError) {} });

    } catch (e) {}
  }

  async function getDeviceId() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "GET_DEVICE_ID" }, (res) => {
        resolve(res?.deviceId || "unknown");
      });
    });
  }

  sendAuth();
  setInterval(sendAuth, 60 * 1000);
  window.addEventListener("storage", (e) => {
    if (e.key && e.key.includes('supabase')) sendAuth();
  });
  setTimeout(sendAuth, 2000);
})();
