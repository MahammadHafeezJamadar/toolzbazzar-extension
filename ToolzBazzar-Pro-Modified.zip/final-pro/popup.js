// ToolzBazzar — Popup v3.0.0
// Stats: Videos / Images / Model Usage

const DASHBOARD_URL = "https://www.toolsbazzar.store";
function $(id) { return document.getElementById(id); }

function initials(name) {
  if (!name) return "?";
  return name.split(" ").filter(Boolean).map(n => n[0]).slice(0, 2).join("").toUpperCase();
}

function show(id) {
  ["loading-screen", "dashboard-screen", "status-screen"].forEach(s => {
    const el = $(s);
    if (el) el.style.display = s === id ? (id === "loading-screen" ? "flex" : "block") : "none";
  });
}

async function loadStats() {
  return new Promise(r => chrome.storage.local.get(
    ['tb_videos', 'tb_images', 'tb_quality_count', 'tb_fast_count'], r
  ));
}

function populateStatus(data, stats) {
  const name = data.userName || "User";
  $("user-name").textContent = name;
  $("user-avatar").textContent = initials(name);
  $("user-email").textContent = data.userEmail || "";
  $("user-plan").textContent = (data.userPlan || "Basic") + " Plan";

  // Subscription badge
  const badge = $("sub-badge");
  const badgeText = $("sub-badge-text");
  const injectBtn = $("inject-flow-btn");
  const openBtn = $("open-flow-btn");
  const subVal = $("sub-val");

  if (data.subscriptionActive) {
    if (subVal) { subVal.textContent = "Active"; subVal.className = "stat-val ok"; }
    badge.className = "badge active";
    badgeText.textContent = "Subscription Active ✓";
    if (injectBtn) injectBtn.style.display = "flex";
    if (openBtn) openBtn.disabled = false;
  } else {
    if (subVal) { subVal.textContent = "Inactive"; subVal.className = "stat-val warn"; }
    badge.className = "badge inactive";
    badgeText.textContent = "Subscription Inactive — Contact Admin";
    if (injectBtn) injectBtn.style.display = "none";
    if (openBtn) openBtn.disabled = true;
  }

  // Stats
  const videos = stats.tb_videos || 0;
  const images = stats.tb_images || 0;
  const qualityCount = stats.tb_quality_count || 0;
  const fastCount = stats.tb_fast_count || 0;
  const totalGen = qualityCount + fastCount;
  const topModel = totalGen === 0
    ? "—"
    : qualityCount >= fastCount ? "Quality" : "Fast";

  const vidEl = $("videos-val");
  const imgEl = $("images-val");
  const modelEl = $("model-val");
  if (vidEl) { vidEl.textContent = videos; vidEl.className = "stat-val ok"; }
  if (imgEl) { imgEl.textContent = images; imgEl.className = "stat-val ok"; }
  if (modelEl) { modelEl.textContent = topModel; modelEl.className = "stat-val ok"; }
}

async function init() {
  try {
    const [data, stats] = await Promise.all([
      new Promise(r => chrome.runtime.sendMessage({ type: "GET_STATUS" }, r)),
      loadStats()
    ]);

    if (data?.loggedIn) {
      show("status-screen");
      populateStatus(data, stats);
    } else {
      show("dashboard-screen");
    }
  } catch (err) {
    show("dashboard-screen");
  }
}

$("open-dashboard-btn")?.addEventListener("click", () => {
  chrome.tabs.create({ url: DASHBOARD_URL, active: true });
  window.close();
});

$("open-flow-btn")?.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "OPEN_FLOW" }, (res) => {
    if (!res?.ok) {
      const reasons = {
        subscription_inactive: "Subscription inactive! Contact admin.",
        expired: "Plan expired! Contact admin.",
        daily_limit_reached: "Daily limit reached! Try tomorrow.",
        not_logged_in: "Please login at the dashboard first!"
      };
      alert(reasons[res?.error] || "Access denied!");
    } else {
      window.close();
    }
  });
});

$("inject-flow-btn")?.addEventListener("click", () => {
  const btn = $("inject-flow-btn");
  btn.disabled = true;
  btn.textContent = "Reconnecting...";
  chrome.runtime.sendMessage({ type: "INJECT_NOW" }, () => {
    btn.disabled = false;
    btn.textContent = "⚡ Reconnect";
  });
});

$("logout-btn")?.addEventListener("click", async () => {
  await new Promise(resolve => chrome.runtime.sendMessage({ type: "LOGOUT" }, resolve));
  show("dashboard-screen");
});

init();
