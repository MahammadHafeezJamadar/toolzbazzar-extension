// ToolzBazzar — Popup v2.1.0
// Dashboard required — no manual login

const SUPABASE_URL = "https://uvvexcaqeoyanvafsdrc.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV2dmV4Y2FxZW95YW52YWZzZHJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2Mzk2MzMsImV4cCI6MjA4ODIxNTYzM30.Ti2c7aMLxL61i9rxyFXtKVoGTHx-6Xyxi0s_t3gq-oM";
const DASHBOARD_URL = "https://www.toolsbazzar.store";

function $(id) { return document.getElementById(id); }

function initials(name) {
  if (!name) return "?";
  return name.split(" ").filter(Boolean).map(n => n[0]).slice(0, 2).join("").toUpperCase();
}

function show(id) {
  ["loading-screen", "dashboard-screen", "status-screen"].forEach(s => {
    const el = $(s);
    if (el) el.style.display = s === id ? (id === "loading-screen" ? "flex" : "block") : "none";
  });
}

function populateStatus(data) {
  const name = data.userName || "User";
  $("user-name").textContent = name;
  $("user-avatar").textContent = initials(name);
  $("user-email").textContent = data.userEmail || "";
  $("user-plan").textContent = (data.userPlan || "Basic") + " Plan";

  const subEl = $("sub-val");
  const badge = $("sub-badge");
  const badgeText = $("sub-badge-text");
  const injectBtn = $("inject-flow-btn");
  const openBtn = $("open-flow-btn");

  if (data.subscriptionActive) {
    subEl.textContent = "Active";
    subEl.className = "stat-val ok";
    badge.className = "badge active";
    badgeText.textContent = "Subscription Active ✓";
    if (injectBtn) injectBtn.style.display = "flex";
    if (openBtn) openBtn.disabled = false;
  } else {
    subEl.textContent = "Inactive";
    subEl.className = "stat-val warn";
    badge.className = "badge inactive";
    badgeText.textContent = "Subscription Inactive — Contact Admin";
    if (injectBtn) injectBtn.style.display = "none";
    if (openBtn) openBtn.disabled = true;
  }

  const creditsEl = $("credits-val");
  if (creditsEl) {
    const remaining = (data.creditsTotal || 1000) - (data.creditsUsed || 0);
    creditsEl.textContent = remaining;
    creditsEl.className = "stat-val " + (remaining > 100 ? "ok" : remaining > 20 ? "warn" : "dim");
  }

  const dailyEl = $("daily-val");
  if (dailyEl) {
    dailyEl.textContent = `${data.creditsUsedToday || 0}/${data.dailyLimit || 100}`;
    const dailyRemaining = (data.dailyLimit || 100) - (data.creditsUsedToday || 0);
    dailyEl.className = "stat-val " + (dailyRemaining > 20 ? "ok" : dailyRemaining > 0 ? "warn" : "dim");
  }
}

async function init() {
  try {
    const data = await new Promise(resolve => {
      chrome.runtime.sendMessage({ type: "GET_STATUS" }, resolve);
    });

    if (data?.loggedIn) {
      show("status-screen");
      populateStatus(data);
    } else {
      // Not logged in — show dashboard required screen
      show("dashboard-screen");
    }
  } catch (err) {
    show("dashboard-screen");
  }
}

// Open Dashboard button
$("open-dashboard-btn")?.addEventListener("click", () => {
  chrome.tabs.create({ url: DASHBOARD_URL, active: true });
  window.close();
});

// Open Flow
$("open-flow-btn")?.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "OPEN_FLOW" }, (res) => {
    if (!res?.ok) {
      const reasons = {
        subscription_inactive: "Subscription inactive! Admin se contact karo.",
        expired: "Plan expired! Admin se contact karo.",
        daily_limit_reached: "Daily limit khatam! Kal aao.",
        not_logged_in: "Pehle dashboard pe login karo!"
      };
      alert(reasons[res?.error] || "Access denied!");
    } else {
      window.close();
    }
  });
});

// Reconnect
$("inject-flow-btn")?.addEventListener("click", () => {
  const btn = $("inject-flow-btn");
  btn.disabled = true;
  btn.textContent = "Reconnecting...";
  chrome.runtime.sendMessage({ type: "INJECT_NOW" }, () => {
    btn.disabled = false;
    btn.textContent = "⚡ Reconnect";
  });
});

// Logout
$("logout-btn")?.addEventListener("click", async () => {
  await new Promise(resolve => chrome.runtime.sendMessage({ type: "LOGOUT" }, resolve));
  show("dashboard-screen");
});

init();
