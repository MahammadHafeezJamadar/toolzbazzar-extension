// ToolzBazzar — Content Script v3.0.0
// Fixed: Credits only cut when video/image actually generated
// Fast model = 10 credits, Quality model = 100 credits, Image = 10 credits

let indicator = null;
let statusTimeout = null;
let watermark = null;
const knownMediaKeys = new Set();
let _seedingPhase = true;

// ── Status Toast ──
function showStatus(message, type = "success") {
  if (!indicator) {
    indicator = document.createElement("div");
    indicator.style.cssText = `
      position: fixed; bottom: 18px; right: 18px;
      background: rgba(12,12,12,0.96); color: #fff;
      border-radius: 8px; padding: 9px 13px;
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
      font-size: 12px; display: flex; align-items: center; gap: 7px;
      z-index: 2147483647; box-shadow: 0 4px 24px rgba(0,0,0,0.4);
      border: 1px solid rgba(255,255,255,0.08);
      transition: opacity 0.3s ease; pointer-events: none;
    `;
    document.body.appendChild(indicator);
  }
  const colors = { success: "#22c55e", warning: "#f59e0b", error: "#ef4444", info: "#3b82f6" };
  const color = colors[type] || colors.success;
  indicator.style.opacity = "1";
  indicator.innerHTML = `
    <div style="width:7px;height:7px;border-radius:50%;background:${color};box-shadow:0 0 5px ${color};flex-shrink:0"></div>
    <span>${message}</span>
  `;
  if (statusTimeout) clearTimeout(statusTimeout);
  statusTimeout = setTimeout(() => { if (indicator) indicator.style.opacity = "0"; }, 5000);
}

// ── Watermark ──
function addWatermark(userName) {
  if (watermark) return;
  watermark = document.createElement("div");
  watermark.style.cssText = `
    position: fixed; top: 50%; left: 50%;
    transform: translate(-50%, -50%) rotate(-30deg);
    font-size: 28px; font-weight: 700;
    color: rgba(255,255,255,0.04);
    pointer-events: none; z-index: 999999;
    font-family: -apple-system, sans-serif;
    white-space: nowrap; user-select: none;
    text-transform: uppercase; letter-spacing: 4px;
  `;
  watermark.textContent = `ToolsBazzar • ${userName || 'Licensed'}`;
  document.body.appendChild(watermark);
}

// ── Access Denied ──
function showAccessDenied(reason) {
  const messages = {
    subscription_inactive: "❌ Subscription Inactive\nContact admin to renew.",
    expired: "⏰ Plan Expired\nContact admin to renew.",
    device_limit: "📱 Device Limit Reached\nMax 2 devices allowed.",
    not_logged_in: "🔒 Please login at ToolsBazzar website first.",
    daily_limit_reached: "⚡ Daily Limit Reached\nCome back tomorrow!",
  };

  const existing = document.getElementById("tb-access-denied");
  if (existing) existing.remove();

  const overlay = document.createElement("div");
  overlay.id = "tb-access-denied";
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.95); z-index: 2147483647;
    display: flex; align-items: center; justify-content: center;
    font-family: -apple-system, sans-serif;
  `;
  overlay.innerHTML = `
    <div style="text-align:center;padding:40px;background:#111;border-radius:16px;border:1px solid #333;max-width:400px;">
      <div style="font-size:48px;margin-bottom:16px;">🔒</div>
      <div style="font-size:20px;font-weight:700;margin-bottom:12px;color:#ef4444;">Access Denied</div>
      <div style="font-size:14px;color:#999;line-height:1.6;white-space:pre-line;">${messages[reason] || 'Access denied.'}</div>
      <div style="margin-top:20px;font-size:12px;color:#555;">ToolsBazzar</div>
    </div>
  `;
  document.body.appendChild(overlay);
}

// ── Daily Limit Banner ──
function showDailyLimitBanner(usedToday, dailyLimit) {
  const existing = document.getElementById("tb-daily-banner");
  if (existing) existing.remove();

  const remaining = dailyLimit - usedToday;
  const percent = Math.min((usedToday / dailyLimit) * 100, 100);
  const isLow = remaining <= 20;

  if (remaining <= 0) {
    showAccessDenied("daily_limit_reached");
    return;
  }

  const banner = document.createElement("div");
  banner.id = "tb-daily-banner";
  banner.style.cssText = `
    position: fixed; top: 10px; right: 10px;
    background: rgba(12,12,12,0.96); color: #fff;
    border-radius: 10px; padding: 10px 14px;
    font-family: -apple-system, sans-serif; font-size: 11px;
    z-index: 2147483647; border: 1px solid ${isLow ? '#f59e0b' : '#333'};
    min-width: 180px; pointer-events: none;
  `;
  banner.innerHTML = `
    <div style="display:flex;justify-content:space-between;margin-bottom:5px;">
      <span style="color:#888;">Daily Credits</span>
      <span style="color:${isLow ? '#f59e0b' : '#4ade80'};font-weight:700;">${usedToday}/${dailyLimit}</span>
    </div>
    <div style="background:#222;border-radius:4px;height:4px;overflow:hidden;">
      <div style="background:${isLow ? '#f59e0b' : '#4ade80'};height:100%;width:${percent}%;"></div>
    </div>
    ${isLow ? `<div style="color:#f59e0b;margin-top:4px;font-size:10px;">⚠️ ${remaining} credits left!</div>` : ''}
  `;
  document.body.appendChild(banner);
  setTimeout(() => { if (banner) banner.remove(); }, 8000);
}

// ── Detect which model was used ──
function detectCurrentModel() {
  // Look for model selector text on page
  const modelTexts = [...document.querySelectorAll('*')].filter(el => {
    const text = el.textContent.trim().toLowerCase();
    return el.children.length === 0 && (
      text.includes('quality') ||
      text.includes('fast') ||
      text.includes('veo 3.1')
    );
  });

  for (const el of modelTexts) {
    const text = el.textContent.trim().toLowerCase();
    if (text.includes('quality')) return 'quality';
    if (text.includes('fast')) return 'fast';
  }
  return 'fast'; // default to fast
}

// ── Get video src ──
function getVideoSrc(v) {
  return v.currentSrc || v.src || v.querySelector?.("source")?.src || "";
}

// ── Check if generated video ──
function isGeneratedVideo(v) {
  try {
    const src = getVideoSrc(v);
    if (!src || src === window.location.href) return false;
    const w = v.videoWidth || v.clientWidth || 0;
    const h = v.videoHeight || v.clientHeight || 0;
    if (w < 100 && h < 100) return false;
    return true;
  } catch (_) { return false; }
}

// ── Check if generated image ──
function isGeneratedImage(img) {
  try {
    const src = img.src || img.currentSrc || "";
    if (!src || src.startsWith("data:") || src.includes(".svg")) return false;
    const w = img.naturalWidth || img.width || 0;
    const h = img.naturalHeight || img.height || 0;
    if (w < 200 && h < 200) return false;
    const alt = (img.alt || "").toLowerCase();
    if (alt.includes("logo") || alt.includes("icon") || alt.includes("avatar")) return false;
    return true;
  } catch (_) { return false; }
}

// ── Report media — ONLY when actually generated ──
async function reportMedia(mediaType, src) {
  if (_seedingPhase) return;

  // Check daily limit first
  const limitCheck = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "CHECK_DAILY_LIMIT" }, resolve);
  });

  if (limitCheck?.limitReached) {
    showAccessDenied("daily_limit_reached");
    return;
  }

  // Detect model for correct credit cost
  let model = 'fast';
  if (mediaType === 'video') {
    model = detectCurrentModel();
  }

  console.log(`[TB] ${mediaType} detected! Model: ${model}`);

  const result = await new Promise(resolve => {
    chrome.runtime.sendMessage({ 
      type: "MEDIA_DETECTED", 
      mediaType, 
      model,
      src 
    }, resolve);
  });

  if (result?.success) {
    const cost = result.cost;
    const modelLabel = model === 'quality' ? 'Quality' : 'Fast';
    showDailyLimitBanner(result.creditsUsedToday, result.dailyLimit);
    showStatus(
      `${mediaType === 'video' ? '🎬' : '🖼️'} ${mediaType === 'video' ? `Video (${modelLabel})` : 'Image'} — ${cost} credits used`, 
      "info"
    );
  } else if (result?.reason === "daily_limit_reached") {
    showAccessDenied("daily_limit_reached");
  }
}

// ── Scan page for NEW media only ──
function scanPageForMedia() {
  // Videos
  document.querySelectorAll("video").forEach(v => {
    const src = getVideoSrc(v);
    const key = "v:" + src;
    if (!src || knownMediaKeys.has(key)) return;
    if (_seedingPhase) { knownMediaKeys.add(key); return; }
    if (isGeneratedVideo(v)) {
      knownMediaKeys.add(key);
      reportMedia("video", src);
    }
  });

  // Images
  document.querySelectorAll("img").forEach(img => {
    const src = img.src || img.currentSrc || "";
    const key = "i:" + src;
    if (!src || knownMediaKeys.has(key)) return;
    if (_seedingPhase) { knownMediaKeys.add(key); return; }
    if (isGeneratedImage(img)) {
      knownMediaKeys.add(key);
      reportMedia("image", src);
    }
  });
}

// MutationObserver — only for NEW elements
new MutationObserver((mutations) => {
  if (_seedingPhase) return;
  for (const m of mutations) {
    for (const node of m.addedNodes) {
      if (node.nodeType !== 1) continue;
      const videos = node.tagName === "VIDEO" ? [node] : [...(node.querySelectorAll?.("video") || [])];
      for (const v of videos) {
        const src = getVideoSrc(v);
        const key = "v:" + src;
        if (src && !knownMediaKeys.has(key)) {
          knownMediaKeys.add(key);
          reportMedia("video", src);
        }
      }
    }
  }
}).observe(document.documentElement, { childList: true, subtree: true });

// ── Init — seed existing media first ──
setTimeout(() => {
  scanPageForMedia(); // Seed existing — no credits
  _seedingPhase = false;
  console.log("[TB] Media scanner ready — monitoring NEW media only!");
}, 5000); // Wait 5 seconds before monitoring

// Scan every 30 seconds for new media only
setInterval(() => {
  if (!_seedingPhase) scanPageForMedia();
}, 30000);

// ── Message handler ──
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "COOKIES_INJECTED") showStatus("ToolsBazzar Active ✓", "success");
  if (message.type === "SESSION_ACTIVE") {
    showStatus("ToolsBazzar Active ✓", "success");
    chrome.storage.local.get(["userName"], (data) => addWatermark(data.userName));
  }
  if (message.type === "ACCESS_DENIED") showAccessDenied(message.reason);
  if (message.type === "NOT_LOGGED_IN") showAccessDenied("not_logged_in");
  if (message.type === "NO_COOKIES") showStatus("No session — contact admin", "warning");
});

// On load
chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
  if (chrome.runtime.lastError) return;
  if (response?.loggedIn && response?.subscriptionActive) {
    addWatermark(response.userName);
    if (response.dailyRemaining <= 0) {
      showAccessDenied("daily_limit_reached");
    } else if (response.dailyRemaining <= 20) {
      showStatus(`⚠️ Only ${response.dailyRemaining} daily credits left!`, "warning");
    }
  }
});

// ── HIDE ULTRA BADGE + GOOGLE ACCOUNT AVATAR ──
const tbStyle = document.createElement('style');
tbStyle.id = 'tb-hide-elements';
tbStyle.textContent = `
  [class*="plan-badge"], [class*="tier-badge"], [class*="subscription-badge"] { display: none !important; }
  header button[style*="border-radius: 50%"], header button[style*="border-radius:50%"],
  [aria-label*="Google Account"], [aria-label*="account"] { display: none !important; }
`;
if (!document.getElementById('tb-hide-elements')) {
  (document.head || document.documentElement).appendChild(tbStyle);
}

function hideFlowElements() {
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0 && el.textContent.trim() === 'ULTRA') {
      const parent = el.closest('button, [class*="badge"], [class*="plan"], span');
      if (parent) parent.style.setProperty('display', 'none', 'important');
    }
  });

  document.querySelectorAll('header button, nav button').forEach(btn => {
    const text = btn.textContent.trim();
    const rect = btn.getBoundingClientRect();
    const style = window.getComputedStyle(btn);
    if (text.length <= 2 && /^[a-zA-Z]+$/.test(text) &&
        style.borderRadius.includes('50%') && rect.top < 100 && rect.right > window.innerWidth - 200) {
      btn.style.setProperty('display', 'none', 'important');
    }
    const label = (btn.getAttribute('aria-label') || '').toLowerCase();
    if (label.includes('google account') || label.includes('account') || label.includes('signed in')) {
      btn.style.setProperty('display', 'none', 'important');
    }
  });
}

document.addEventListener('DOMContentLoaded', hideFlowElements);
window.addEventListener('load', hideFlowElements);
setInterval(hideFlowElements, 500);
new MutationObserver(() => hideFlowElements()).observe(document.documentElement, { childList: true, subtree: true });
