// ToolzBazzar — Content Script v3.5.0
// Model rename + Credits display + 4K hide + Stats tracking

let indicator = null;
let statusTimeout = null;
let watermark = null;
const knownMediaKeys = new Set();
let _seedingPhase = true;
let _tbSelectedModel = 'a'; // 'a'=Quality label, 'b'=Fast label

// ── Status Toast ──
function showStatus(message, type = "success") {
  if (!indicator) {
    indicator = document.createElement("div");
    indicator.style.cssText = `
      position: fixed; bottom: 18px; right: 18px;
      background: rgba(12,12,12,0.96); color: #fff;
      border-radius: 8px; padding: 9px 13px;
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
      font-size: 12px; display: flex; align-items: center; gap: 7px;
      z-index: 2147483647; box-shadow: 0 4px 24px rgba(0,0,0,0.4);
      border: 1px solid rgba(255,255,255,0.08);
      transition: opacity 0.3s ease; pointer-events: none;
    `;
    document.body.appendChild(indicator);
  }
  const colors = { success: "#22c55e", warning: "#f59e0b", error: "#ef4444", info: "#3b82f6" };
  const color = colors[type] || colors.success;
  indicator.style.opacity = "1";
  indicator.innerHTML = `
    <div style="width:7px;height:7px;border-radius:50%;background:${color};box-shadow:0 0 5px ${color};flex-shrink:0"></div>
    <span>${message}</span>
  `;
  if (statusTimeout) clearTimeout(statusTimeout);
  statusTimeout = setTimeout(() => { if (indicator) indicator.style.opacity = "0"; }, 5000);
}

// ── Watermark ──
function addWatermark(userName) {
  if (watermark) return;
  watermark = document.createElement("div");
  watermark.style.cssText = `
    position: fixed; top: 50%; left: 50%;
    transform: translate(-50%, -50%) rotate(-30deg);
    font-size: 28px; font-weight: 700;
    color: rgba(255,255,255,0.04);
    pointer-events: none; z-index: 999999;
    font-family: -apple-system, sans-serif;
    white-space: nowrap; user-select: none;
    text-transform: uppercase; letter-spacing: 4px;
  `;
  watermark.textContent = `ToolsBazzar • ${userName || 'Licensed'}`;
  document.body.appendChild(watermark);
}

// ── Access Denied ──
function showAccessDenied(reason) {
  const messages = {
    subscription_inactive: "❌ Subscription Inactive\nContact admin to renew.",
    expired: "⏰ Plan Expired\nContact admin to renew.",
    not_logged_in: "🔒 Please login at ToolsBazzar website first.",
    daily_limit_reached: "⚡ Daily Limit Reached\nCome back tomorrow!",
  };
  const existing = document.getElementById("tb-access-denied");
  if (existing) existing.remove();
  const overlay = document.createElement("div");
  overlay.id = "tb-access-denied";
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.95); z-index: 2147483647;
    display: flex; align-items: center; justify-content: center;
    font-family: -apple-system, sans-serif;
  `;
  overlay.innerHTML = `
    <div style="text-align:center;padding:40px;background:#111;border-radius:16px;border:1px solid #333;max-width:400px;">
      <div style="font-size:48px;margin-bottom:16px;">🔒</div>
      <div style="font-size:20px;font-weight:700;margin-bottom:12px;color:#ef4444;">Access Denied</div>
      <div style="font-size:14px;color:#999;line-height:1.6;white-space:pre-line;">${messages[reason] || 'Access denied.'}</div>
      <div style="margin-top:20px;font-size:12px;color:#555;">ToolsBazzar</div>
    </div>
  `;
  document.body.appendChild(overlay);
}

// ── Always fast for background ──
function detectCurrentModel() { return 'fast'; }

// ── Get video src ──
function getVideoSrc(v) {
  return v.currentSrc || v.src || v.querySelector?.("source")?.src || "";
}

function isGeneratedVideo(v) {
  try {
    const src = getVideoSrc(v);
    if (!src || src === window.location.href) return false;
    const w = v.videoWidth || v.clientWidth || 0;
    const h = v.videoHeight || v.clientHeight || 0;
    if (w < 100 && h < 100) return false;
    return true;
  } catch (_) { return false; }
}

function isGeneratedImage(img) {
  try {
    const src = img.src || img.currentSrc || "";
    if (!src || src.startsWith("data:") || src.includes(".svg")) return false;
    const w = img.naturalWidth || img.width || 0;
    const h = img.naturalHeight || img.height || 0;
    if (w < 200 && h < 200) return false;
    const alt = (img.alt || "").toLowerCase();
    if (alt.includes("logo") || alt.includes("icon") || alt.includes("avatar")) return false;
    return true;
  } catch (_) { return false; }
}

// ── Track generation stats ──
async function trackGeneration(mediaType) {
  try {
    const data = await new Promise(r => chrome.storage.local.get(
      ['tb_videos', 'tb_images', 'tb_quality_count', 'tb_fast_count'], r
    ));
    const update = {};
    if (mediaType === 'video') update.tb_videos = (data.tb_videos || 0) + 1;
    if (mediaType === 'image') update.tb_images = (data.tb_images || 0) + 1;
    // Always fast in background, but track what user "selected"
    if (_tbSelectedModel === 'quality') {
      update.tb_quality_count = (data.tb_quality_count || 0) + 1;
    } else {
      update.tb_fast_count = (data.tb_fast_count || 0) + 1;
    }
    chrome.storage.local.set(update);
  } catch (_) {}
}

// ── Report media ──
async function reportMedia(mediaType, src) {
  if (_seedingPhase) return;
  const limitCheck = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "CHECK_DAILY_LIMIT" }, resolve);
  });
  if (limitCheck?.limitReached) {
    showAccessDenied("daily_limit_reached");
    return;
  }
  const result = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "MEDIA_DETECTED", mediaType, model: 'fast', src }, resolve);
  });
  if (result?.success) {
    trackGeneration(mediaType);
    showStatus(`${mediaType === 'video' ? '🎬 Video' : '🖼️ Image'} generated!`, "success");
  } else if (result?.reason === "daily_limit_reached") {
    showAccessDenied("daily_limit_reached");
  }
}

// ── Scan page for NEW media ──
function scanPageForMedia() {
  document.querySelectorAll("video").forEach(v => {
    const src = getVideoSrc(v);
    const key = "v:" + src;
    if (!src || knownMediaKeys.has(key)) return;
    if (_seedingPhase) { knownMediaKeys.add(key); return; }
    if (isGeneratedVideo(v)) { knownMediaKeys.add(key); reportMedia("video", src); }
  });
  document.querySelectorAll("img").forEach(img => {
    const src = img.src || img.currentSrc || "";
    const key = "i:" + src;
    if (!src || knownMediaKeys.has(key)) return;
    if (_seedingPhase) { knownMediaKeys.add(key); return; }
    if (isGeneratedImage(img)) { knownMediaKeys.add(key); reportMedia("image", src); }
  });
}

new MutationObserver((mutations) => {
  if (_seedingPhase) return;
  for (const m of mutations) {
    for (const node of m.addedNodes) {
      if (node.nodeType !== 1) continue;
      const videos = node.tagName === "VIDEO" ? [node] : [...(node.querySelectorAll?.("video") || [])];
      for (const v of videos) {
        const src = getVideoSrc(v);
        const key = "v:" + src;
        if (src && !knownMediaKeys.has(key)) { knownMediaKeys.add(key); reportMedia("video", src); }
      }
    }
  }
}).observe(document.documentElement, { childList: true, subtree: true });

setTimeout(() => {
  scanPageForMedia();
  _seedingPhase = false;
}, 5000);
setInterval(() => { if (!_seedingPhase) scanPageForMedia(); }, 30000);

// ════════════════════════════════════════════════
// UI PATCHES
// ════════════════════════════════════════════════

// ── Global Styles ──
const tbStyle = document.createElement('style');
tbStyle.id = 'tb-hide-elements';
tbStyle.textContent = `
  [class*="plan-badge"], [class*="tier-badge"], [class*="subscription-badge"] { display: none !important; }
  [aria-label*="Google Account"], [aria-label*="account"] { display: none !important; }
  [data-tb-google-sel="1"] { display: none !important; pointer-events: none !important; }
`;
if (!document.getElementById('tb-hide-elements')) {
  (document.head || document.documentElement).appendChild(tbStyle);
}

// ── Build Custom Model Selector ──
// ══════════════════════════════════════════════════
// SIMPLE APPROACH:
// 1. Find Google's model selector button
// 2. Hide it, inject our UI in its exact place
// ══════════════════════════════════════════════════

// ── Hide ALL model selectors + generating info ──
function runUiPatches() {
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length !== 0) return;
    const text = el.textContent.trim();

    // Hide ULTRA/PRO/BASIC badge
    if (text === 'ULTRA' || text === 'PRO' || text === 'BASIC') {
      const p = el.closest('button, [class*="badge"], [class*="plan"], span');
      if (p) p.style.setProperty('display', 'none', 'important');
      return;
    }

    // Hide "Generating will use X credits" line
    if (text.includes('Generating will use') && text.includes('credits')) {
      const row = el.closest('div, p, span') || el;
      row.style.setProperty('display', 'none', 'important');
      return;
    }

    // Hide 4K option
    if (text === '4K' || text.includes('50 credits') || text.toLowerCase().includes('upscaled · 50')) {
      const row = el.closest('li, [role="menuitem"], [role="option"], div[class]') || el;
      row.style.setProperty('display', 'none', 'important');
      return;
    }

    // Rename "Veo 3.1 - Fast" → "Veo 3.1 - Quality" (display only)
    if (text === 'Veo 3.1 - Fast' && !el.dataset.tbRenamed) {
      el.textContent = 'Veo 3.1 - Quality';
      el.dataset.tbRenamed = '1';
      return;
    }

    // Hide dropdown options: real Quality + Lower Priority
    if (
      (text === 'Veo 3.1 - Quality' && !el.dataset.tbRenamed) ||
      text === 'Veo 3.1 - Fast [Lower Priority]'
    ) {
      const row = el.closest('[role="option"], [role="menuitem"], li') || el.parentElement;
      if (row) row.style.setProperty('display', 'none', 'important');
      el.style.setProperty('display', 'none', 'important');
      return;
    }
  });

  // Find model selector container and lock it — hide toggle SVG, disable pointer events on arrow
  document.querySelectorAll('[role="combobox"], button').forEach(el => {
    const txt = el.textContent.trim();
    // The main model combobox/button
    if (txt === 'Veo 3.1 - Quality' || txt === 'Veo 3.1 - Fast') {
      // Hide all SVG icons inside (the dropdown arrow)
      el.querySelectorAll('svg').forEach(s => s.style.setProperty('display', 'none', 'important'));
      // Prevent opening dropdown
      el.style.setProperty('pointer-events', 'none', 'important');
      return;
    }
  });

  // Hide the standalone chevron/toggle button next to model row
  // It's a small button with only SVG, sibling or child of model selector area
  document.querySelectorAll('button').forEach(btn => {
    if (btn.dataset.tbArrowHidden) return;
    const txt = btn.textContent.trim();
    if (txt !== '') return; // only pure-icon buttons
    const hasSvg = !!btn.querySelector('svg');
    if (!hasSvg) return;
    const rect = btn.getBoundingClientRect();
    if (rect.width === 0) return;
    // Check if parent/sibling has Veo text
    const container = btn.closest('div, form, [class]');
    if (container && container.textContent.includes('Veo 3.1')) {
      btn.style.setProperty('display', 'none', 'important');
      btn.dataset.tbArrowHidden = '1';
    }
  });

  // Hide Google Account button
  document.querySelectorAll('header button, nav button').forEach(btn => {
    const label = (btn.getAttribute('aria-label') || '').toLowerCase();
    if (label.includes('google account') || label.includes('signed in')) {
      btn.style.setProperty('display', 'none', 'important');
    }
  });
}

document.addEventListener('DOMContentLoaded', runUiPatches);
window.addEventListener('load', runUiPatches);
setInterval(runUiPatches, 300);
new MutationObserver(runUiPatches).observe(document.documentElement, { childList: true, subtree: true });


// ── Message handler ──
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "COOKIES_INJECTED") showStatus("ToolsBazzar Active ✓", "success");
  if (message.type === "SESSION_ACTIVE") {
    showStatus("ToolsBazzar Active ✓", "success");
    chrome.storage.local.get(["userName"], (data) => addWatermark(data.userName));
  }
  if (message.type === "ACCESS_DENIED") showAccessDenied(message.reason);
  if (message.type === "NO_COOKIES") showStatus("No session — contact admin", "warning");
});

// On load
chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
  if (chrome.runtime.lastError) return;
  if (response?.loggedIn && response?.subscriptionActive) {
    addWatermark(response.userName);
    if (response.dailyRemaining <= 0) showAccessDenied("daily_limit_reached");
  }
});

// ══════════════════════════════════════════════════
// HEARTBEAT — Detect extension removal → Auto logout
// Pings background every 3s. If no response →
// extension was removed → redirect to Google logout
// ══════════════════════════════════════════════════
(function startHeartbeat() {
  let _missedPings = 0;

  setInterval(() => {
    try {
      chrome.runtime.sendMessage({ type: 'TB_HEARTBEAT' }, (response) => {
        if (chrome.runtime.lastError || !response?.alive) {
          _missedPings++;
          // 2 consecutive misses = extension removed
          if (_missedPings >= 2) {
            console.log('[TB] Extension removed — logging out...');
            // Clear all cookies via document (non-HttpOnly ones)
            document.cookie.split(';').forEach(c => {
              const name = c.trim().split('=')[0];
              document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=.google.com`;
              document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=labs.google`;
            });
            // Navigate to Google logout
            window.location.href = 'https://accounts.google.com/Logout?continue=https://labs.google/fx/tools/flow';
          }
        } else {
          _missedPings = 0; // reset on success
        }
      });
    } catch(e) {
      _missedPings++;
      if (_missedPings >= 2) {
        window.location.href = 'https://accounts.google.com/Logout?continue=https://labs.google/fx/tools/flow';
      }
    }
  }, 3000);
})();

