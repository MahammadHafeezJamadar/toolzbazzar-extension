// ToolzBazzar — Content Script v3.5.0
// Model rename + Credits display + 4K hide + Stats tracking

let indicator = null;
let statusTimeout = null;
let watermark = null;
const knownMediaKeys = new Set();
let _seedingPhase = true;
let _tbSelectedModel = 'quality'; // what user sees (always fast in background)

// ── Status Toast ──
function showStatus(message, type = "success") {
  if (!indicator) {
    indicator = document.createElement("div");
    indicator.style.cssText = `
      position: fixed; bottom: 18px; right: 18px;
      background: rgba(12,12,12,0.96); color: #fff;
      border-radius: 8px; padding: 9px 13px;
      font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif;
      font-size: 12px; display: flex; align-items: center; gap: 7px;
      z-index: 2147483647; box-shadow: 0 4px 24px rgba(0,0,0,0.4);
      border: 1px solid rgba(255,255,255,0.08);
      transition: opacity 0.3s ease; pointer-events: none;
    `;
    document.body.appendChild(indicator);
  }
  const colors = { success: "#22c55e", warning: "#f59e0b", error: "#ef4444", info: "#3b82f6" };
  const color = colors[type] || colors.success;
  indicator.style.opacity = "1";
  indicator.innerHTML = `
    <div style="width:7px;height:7px;border-radius:50%;background:${color};box-shadow:0 0 5px ${color};flex-shrink:0"></div>
    <span>${message}</span>
  `;
  if (statusTimeout) clearTimeout(statusTimeout);
  statusTimeout = setTimeout(() => { if (indicator) indicator.style.opacity = "0"; }, 5000);
}

// ── Watermark ──
function addWatermark(userName) {
  if (watermark) return;
  watermark = document.createElement("div");
  watermark.style.cssText = `
    position: fixed; top: 50%; left: 50%;
    transform: translate(-50%, -50%) rotate(-30deg);
    font-size: 28px; font-weight: 700;
    color: rgba(255,255,255,0.04);
    pointer-events: none; z-index: 999999;
    font-family: -apple-system, sans-serif;
    white-space: nowrap; user-select: none;
    text-transform: uppercase; letter-spacing: 4px;
  `;
  watermark.textContent = `ToolsBazzar • ${userName || 'Licensed'}`;
  document.body.appendChild(watermark);
}

// ── Access Denied ──
function showAccessDenied(reason) {
  const messages = {
    subscription_inactive: "❌ Subscription Inactive\nContact admin to renew.",
    expired: "⏰ Plan Expired\nContact admin to renew.",
    not_logged_in: "🔒 Please login at ToolsBazzar website first.",
    daily_limit_reached: "⚡ Daily Limit Reached\nCome back tomorrow!",
  };
  const existing = document.getElementById("tb-access-denied");
  if (existing) existing.remove();
  const overlay = document.createElement("div");
  overlay.id = "tb-access-denied";
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.95); z-index: 2147483647;
    display: flex; align-items: center; justify-content: center;
    font-family: -apple-system, sans-serif;
  `;
  overlay.innerHTML = `
    <div style="text-align:center;padding:40px;background:#111;border-radius:16px;border:1px solid #333;max-width:400px;">
      <div style="font-size:48px;margin-bottom:16px;">🔒</div>
      <div style="font-size:20px;font-weight:700;margin-bottom:12px;color:#ef4444;">Access Denied</div>
      <div style="font-size:14px;color:#999;line-height:1.6;white-space:pre-line;">${messages[reason] || 'Access denied.'}</div>
      <div style="margin-top:20px;font-size:12px;color:#555;">ToolsBazzar</div>
    </div>
  `;
  document.body.appendChild(overlay);
}

// ── Always fast for background ──
function detectCurrentModel() { return 'fast'; }

// ── Get video src ──
function getVideoSrc(v) {
  return v.currentSrc || v.src || v.querySelector?.("source")?.src || "";
}

function isGeneratedVideo(v) {
  try {
    const src = getVideoSrc(v);
    if (!src || src === window.location.href) return false;
    const w = v.videoWidth || v.clientWidth || 0;
    const h = v.videoHeight || v.clientHeight || 0;
    if (w < 100 && h < 100) return false;
    return true;
  } catch (_) { return false; }
}

function isGeneratedImage(img) {
  try {
    const src = img.src || img.currentSrc || "";
    if (!src || src.startsWith("data:") || src.includes(".svg")) return false;
    const w = img.naturalWidth || img.width || 0;
    const h = img.naturalHeight || img.height || 0;
    if (w < 200 && h < 200) return false;
    const alt = (img.alt || "").toLowerCase();
    if (alt.includes("logo") || alt.includes("icon") || alt.includes("avatar")) return false;
    return true;
  } catch (_) { return false; }
}

// ── Track generation stats ──
async function trackGeneration(mediaType) {
  try {
    const data = await new Promise(r => chrome.storage.local.get(
      ['tb_videos', 'tb_images', 'tb_quality_count', 'tb_fast_count'], r
    ));
    const update = {};
    if (mediaType === 'video') update.tb_videos = (data.tb_videos || 0) + 1;
    if (mediaType === 'image') update.tb_images = (data.tb_images || 0) + 1;
    // Always fast in background, but track what user "selected"
    if (_tbSelectedModel === 'quality') {
      update.tb_quality_count = (data.tb_quality_count || 0) + 1;
    } else {
      update.tb_fast_count = (data.tb_fast_count || 0) + 1;
    }
    chrome.storage.local.set(update);
  } catch (_) {}
}

// ── Report media ──
async function reportMedia(mediaType, src) {
  if (_seedingPhase) return;
  const limitCheck = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "CHECK_DAILY_LIMIT" }, resolve);
  });
  if (limitCheck?.limitReached) {
    showAccessDenied("daily_limit_reached");
    return;
  }
  const result = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "MEDIA_DETECTED", mediaType, model: 'fast', src }, resolve);
  });
  if (result?.success) {
    trackGeneration(mediaType);
    showStatus(`${mediaType === 'video' ? '🎬 Video' : '🖼️ Image'} generated!`, "success");
  } else if (result?.reason === "daily_limit_reached") {
    showAccessDenied("daily_limit_reached");
  }
}

// ── Scan page for NEW media ──
function scanPageForMedia() {
  document.querySelectorAll("video").forEach(v => {
    const src = getVideoSrc(v);
    const key = "v:" + src;
    if (!src || knownMediaKeys.has(key)) return;
    if (_seedingPhase) { knownMediaKeys.add(key); return; }
    if (isGeneratedVideo(v)) { knownMediaKeys.add(key); reportMedia("video", src); }
  });
  document.querySelectorAll("img").forEach(img => {
    const src = img.src || img.currentSrc || "";
    const key = "i:" + src;
    if (!src || knownMediaKeys.has(key)) return;
    if (_seedingPhase) { knownMediaKeys.add(key); return; }
    if (isGeneratedImage(img)) { knownMediaKeys.add(key); reportMedia("image", src); }
  });
}

new MutationObserver((mutations) => {
  if (_seedingPhase) return;
  for (const m of mutations) {
    for (const node of m.addedNodes) {
      if (node.nodeType !== 1) continue;
      const videos = node.tagName === "VIDEO" ? [node] : [...(node.querySelectorAll?.("video") || [])];
      for (const v of videos) {
        const src = getVideoSrc(v);
        const key = "v:" + src;
        if (src && !knownMediaKeys.has(key)) { knownMediaKeys.add(key); reportMedia("video", src); }
      }
    }
  }
}).observe(document.documentElement, { childList: true, subtree: true });

setTimeout(() => {
  scanPageForMedia();
  _seedingPhase = false;
}, 5000);
setInterval(() => { if (!_seedingPhase) scanPageForMedia(); }, 30000);

// ════════════════════════════════════════════════
// UI PATCHES
// ════════════════════════════════════════════════

// ── Global Styles ──
const tbStyle = document.createElement('style');
tbStyle.id = 'tb-hide-elements';
tbStyle.textContent = `
  [class*="plan-badge"], [class*="tier-badge"], [class*="subscription-badge"] { display: none !important; }
  header button[style*="border-radius: 50%"], header button[style*="border-radius:50%"],
  [aria-label*="Google Account"], [aria-label*="account"] { display: none !important; }

  #tb-model-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    background: transparent;
    border: 1px solid rgba(255,255,255,0.15);
    border-radius: 20px;
    color: #e8eaed;
    font-size: 13px;
    font-family: 'Google Sans', -apple-system, sans-serif;
    padding: 5px 12px 5px 10px;
    cursor: pointer;
    user-select: none;
    white-space: nowrap;
    transition: background 0.15s;
    font-weight: 500;
    letter-spacing: 0.01em;
  }
  #tb-model-btn:hover { background: rgba(255,255,255,0.07); }
  #tb-model-menu {
    position: fixed;
    background: #2d2f31;
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    overflow: hidden;
    min-width: 200px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.5);
    z-index: 2147483646;
    display: none;
    flex-direction: column;
    padding: 4px 0;
  }
  #tb-model-menu.open { display: flex; }
  .tb-model-opt {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 16px;
    color: #e8eaed;
    font-size: 13px;
    font-family: 'Google Sans', -apple-system, sans-serif;
    cursor: pointer;
    transition: background 0.1s;
    font-weight: 500;
    gap: 8px;
  }
  .tb-model-opt:hover { background: rgba(255,255,255,0.08); }
  .tb-model-opt .tb-opt-left { display: flex; align-items: center; gap: 10px; }
  .tb-model-opt .tb-opt-icon { font-size: 16px; }
  .tb-model-opt .tb-check-icon {
    width: 18px; height: 18px; color: #8ab4f8;
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; flex-shrink: 0;
  }
`;
if (!document.getElementById('tb-hide-elements')) {
  (document.head || document.documentElement).appendChild(tbStyle);
}

// ── Build Custom Model Selector ──
let _tbSelectorInjected = false;

const TB_OPTS = [
  { id: 'quality', label: 'Veo 3.1 - Quality', icon: '✦' },
  { id: 'fast',    label: 'Veo 3.1 - Fast',    icon: '⚡' },
];

function _tbSilentlyClickFast() {
  // Silently ensure Google's real selector is set to Fast
  const allEls = [...document.querySelectorAll('*')];
  const realTrigger = allEls.find(el =>
    el.children.length === 0 &&
    (el.textContent.trim().startsWith('Veo 3.1 -')) &&
    !el.closest('#tb-model-btn') &&
    !el.closest('#tb-model-menu')
  );
  if (!realTrigger) return;
  const btn = realTrigger.closest('button, [role="button"], [role="combobox"]') || realTrigger;
  btn.click();
  setTimeout(() => {
    const fastOpt = [...document.querySelectorAll('*')].find(el =>
      el.children.length === 0 &&
      (el.textContent.trim() === 'Veo 3.1 - Fast' ||
       el.textContent.trim() === 'Veo 3.1 - Fast [Lower Priority]') &&
      !el.closest('#tb-model-btn') &&
      !el.closest('#tb-model-menu')
    );
    if (fastOpt) {
      (fastOpt.closest('[role="option"], [role="menuitem"], button, li') || fastOpt).click();
    } else {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    }
  }, 60);
}

function _tbBuildMenu(btn) {
  const menu = document.createElement('div');
  menu.id = 'tb-model-menu';

  TB_OPTS.forEach(opt => {
    const row = document.createElement('div');
    row.className = 'tb-model-opt';
    row.innerHTML = `
      <div class="tb-opt-left">
        <span class="tb-opt-icon">${opt.icon}</span>
        <span>${opt.label}</span>
      </div>
      <div class="tb-check-icon" id="tb-check-${opt.id}">${opt.id === _tbSelectedModel ? '✓' : ''}</div>
    `;
    row.addEventListener('click', e => {
      e.stopPropagation();
      _tbSelectedModel = opt.id;
      // Update label on trigger
      const labelEl = document.getElementById('tb-model-label');
      if (labelEl) labelEl.textContent = opt.label;
      // Update checkmarks
      TB_OPTS.forEach(o => {
        const c = document.getElementById('tb-check-' + o.id);
        if (c) c.textContent = (o.id === opt.id) ? '✓' : '';
      });
      // Update "Generating will use X credits" text
      _tbUpdateCreditsText();
      // Close menu
      menu.classList.remove('open');
      // Silently keep Google on Fast
      _tbSilentlyClickFast();
    });
    menu.appendChild(row);
  });

  document.addEventListener('click', e => {
    if (!e.target.closest('#tb-model-btn') && !e.target.closest('#tb-model-menu')) {
      menu.classList.remove('open');
    }
  });

  document.body.appendChild(menu);
  return menu;
}

function _tbInjectSelector() {
  if (_tbSelectorInjected) return;

  // Find Google's real selector button
  const allBtns = [...document.querySelectorAll('button, [role="button"], [role="combobox"]')];
  const realBtn = allBtns.find(el => {
    const t = el.textContent.trim();
    return (t.startsWith('Veo 3.1 -') || t === 'Veo 3.1 - Fast') &&
      !el.id?.startsWith('tb-') &&
      !el.closest('#tb-model-btn');
  });
  if (!realBtn) return;

  // Hide Google's button
  realBtn.style.setProperty('display', 'none', 'important');
  realBtn.setAttribute('data-tb-hidden', '1');

  // Build our button
  const btn = document.createElement('button');
  btn.id = 'tb-model-btn';
  btn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style="opacity:0.8">
      <path d="M12 3a9 9 0 100 18A9 9 0 0012 3zm0 2a7 7 0 110 14A7 7 0 0112 5z"/>
      <path d="M12 7v5l3.5 3.5-1.4 1.4L10 13.2V7z"/>
    </svg>
    <span id="tb-model-label">Veo 3.1 - Quality</span>
    <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" style="opacity:0.6">
      <path d="M7 10l5 5 5-5z"/>
    </svg>
  `;

  const menu = _tbBuildMenu(btn);

  btn.addEventListener('click', e => {
    e.stopPropagation();
    const rect = btn.getBoundingClientRect();
    menu.style.left = rect.left + 'px';
    menu.style.top = (rect.bottom + 4) + 'px';
    menu.classList.toggle('open');
  });

  realBtn.parentElement.insertBefore(btn, realBtn);
  _tbSelectorInjected = true;

  // Set initial Fast selection silently
  setTimeout(_tbSilentlyClickFast, 300);
}

// ── Patch "Generating will use X credits" text ──
function _tbUpdateCreditsText() {
  const cost = _tbSelectedModel === 'quality' ? 100 : 20;
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0 && el.textContent.includes('Generating will use')) {
      const match = el.textContent.match(/Generating will use\s+\d+\s+credits?/i);
      if (match) {
        el.textContent = el.textContent.replace(
          /Generating will use\s+\d+\s+credits?/i,
          `Generating will use ${cost} credits`
        );
      }
    }
  });
}

// ── Hide 4K download option ──
function _tbHide4K() {
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0) {
      const text = el.textContent.trim();
      if (text === '4K') {
        // Hide the whole download option row
        const row = el.closest('li, [role="menuitem"], [role="option"], div[class]');
        if (row) row.style.setProperty('display', 'none', 'important');
        else {
          el.style.setProperty('display', 'none', 'important');
          if (el.parentElement) el.parentElement.style.setProperty('display', 'none', 'important');
        }
      }
      // Also hide by "50 credits" text which only appears on 4K
      if (text.includes('50 credits') || text.toLowerCase().includes('upscaled · 50')) {
        const row = el.closest('li, [role="menuitem"], div[class]');
        if (row) row.style.setProperty('display', 'none', 'important');
      }
    }
  });
}

// ── Hide model name in sidebar/description ──
function _tbHideSidebarModel() {
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0 && !el.closest('#tb-model-btn') && !el.closest('#tb-model-menu')) {
      const text = el.textContent.trim();
      if (
        text === 'Veo 3.1 - Fast' ||
        text === 'Veo 3.1 - Fast [Lower Priority]' ||
        text === 'Veo 3.1 - Quality'
      ) {
        el.style.setProperty('display', 'none', 'important');
      }
    }
  });
}

// ── Hide ULTRA/PRO/BASIC badge ──
function _tbHideBadge() {
  document.querySelectorAll('*').forEach(el => {
    if (el.children.length === 0) {
      const t = el.textContent.trim();
      if (t === 'ULTRA' || t === 'PRO' || t === 'BASIC') {
        const parent = el.closest('button, [class*="badge"], [class*="plan"], span');
        if (parent) parent.style.setProperty('display', 'none', 'important');
      }
    }
  });
}

// ── Hide Google Account button ──
function _tbHideGoogleAccount() {
  document.querySelectorAll('header button, nav button').forEach(btn => {
    const text = btn.textContent.trim();
    const rect = btn.getBoundingClientRect();
    const style = window.getComputedStyle(btn);
    if (text.length <= 2 && /^[a-zA-Z]+$/.test(text) &&
        style.borderRadius.includes('50%') && rect.top < 100 && rect.right > window.innerWidth - 200) {
      btn.style.setProperty('display', 'none', 'important');
    }
    const label = (btn.getAttribute('aria-label') || '').toLowerCase();
    if (label.includes('google account') || label.includes('account') || label.includes('signed in')) {
      btn.style.setProperty('display', 'none', 'important');
    }
  });
}

// ── Main UI patcher (runs periodically) ──
function runUiPatches() {
  _tbInjectSelector();
  _tbUpdateCreditsText();
  _tbHide4K();
  _tbHideSidebarModel();
  _tbHideBadge();
  _tbHideGoogleAccount();
}

document.addEventListener('DOMContentLoaded', runUiPatches);
window.addEventListener('load', runUiPatches);
setInterval(runUiPatches, 500);
new MutationObserver(runUiPatches).observe(document.documentElement, { childList: true, subtree: true });

// ── Message handler ──
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "COOKIES_INJECTED") showStatus("ToolsBazzar Active ✓", "success");
  if (message.type === "SESSION_ACTIVE") {
    showStatus("ToolsBazzar Active ✓", "success");
    chrome.storage.local.get(["userName"], (data) => addWatermark(data.userName));
  }
  if (message.type === "ACCESS_DENIED") showAccessDenied(message.reason);
  if (message.type === "NO_COOKIES") showStatus("No session — contact admin", "warning");
});

// On load
chrome.runtime.sendMessage({ type: "GET_STATUS" }, (response) => {
  if (chrome.runtime.lastError) return;
  if (response?.loggedIn && response?.subscriptionActive) {
    addWatermark(response.userName);
    if (response.dailyRemaining <= 0) showAccessDenied("daily_limit_reached");
  }
});
